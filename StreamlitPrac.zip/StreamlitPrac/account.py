import streamlit as st
import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
import json
import requests

# Initialize Firebase app with credentials
cred = credentials.Certificate("authentication-5e874-b8b6cc49873c.json")
firebase_admin.initialize_app(cred)

def app():
    st.title('Welcome to :violet[Pondering] :sunglasses:')

    # Session state initialization
    if 'username' not in st.session_state:
        st.session_state.username = ''
    if 'useremail' not in st.session_state:
        st.session_state.useremail = ''
    if 'signedout' not in st.session_state:
        st.session_state['signedout'] = False
    if 'signout' not in st.session_state:
        st.session_state['signout'] = False  

    # Function to sign up user with email and password
    def sign_up_with_email_and_password(email, password, username=None):
        try:
            user = auth.create_user(
                email=email,
                password=password,
                display_name=username
            )
            return user
        except Exception as e:
            st.warning(f'Signup failed: {str(e)}')

    # Function to sign in user with email and password
    def sign_in_with_email_and_password(email, password):
        try:
            user = auth.get_user_by_email(email)
            # You could implement additional checks here if needed
            st.session_state.username = user.display_name
            st.session_state.useremail = user.email
            return user
        except Exception as e:
            st.warning(f'Signin failed: {str(e)}')

    # Function to reset password
    def reset_password(email):
        try:
            auth.send_password_reset_email(email)
            st.success("Password reset email sent successfully.")
        except Exception as e:
            st.warning(f"Password reset failed: {str(e)}") 

    # User interface for signup/login
    if not st.session_state["signedout"]:
        choice = st.selectbox('Login/Signup', ['Login', 'Sign up'])
        email = st.text_input('Email Address')
        password = st.text_input('Password', type='password')

        if choice == 'Sign up':
            username = st.text_input("Enter your unique username")
            if st.button('Create my account'):
                user = sign_up_with_email_and_password(email=email, password=password, username=username)
                if user:
                    st.success('Account created successfully! Please login.')
                    st.balloons()
        else:
            if st.button('Login'):
                user = sign_in_with_email_and_password(email=email, password=password)
                if user:
                    st.session_state.signedout = True
                    st.text(f'Welcome {st.session_state.username}!')

        if st.button('Forgot Password'):
            reset_email = st.text_input('Enter your email for password reset')
            if st.button('Send Reset Link'):
                reset_password(reset_email)

    if st.session_state.signout:
        st.text('Name: ' + st.session_state.username)
        st.text('Email ID: ' + st.session_state.useremail)
        if st.button('Sign out'):
            st.session_state.signout = False
            st.session_state.username = ''
            st.session_state.useremail = ''

