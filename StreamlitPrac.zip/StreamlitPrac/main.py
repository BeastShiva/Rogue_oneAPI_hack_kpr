import streamlit as st
from streamlit_option_menu import option_menu
import os
from dotenv import load_dotenv
import firebase_admin
from firebase_admin import credentials, auth, storage
import re  # Import regular expressions for email validation

# Load environment variables
load_dotenv()

# Firebase app initialization
if not firebase_admin._apps:  # Check if the app is already initialized
    cred = credentials.Certificate("authentication-5e874-b8b6cc49873c.json")  # Update with your credentials path
    firebase_admin.initialize_app(cred, {
        'storageBucket': 'authentication-5e874.appspot.com'  # Use your actual bucket name
    })

# Set page configuration
st.set_page_config(page_title="Pondering")

class MultiApp:
    def __init__(self):
        self.apps = []

    def add_app(self, title, func):
        self.apps.append({"title": title, "function": func})

    def run(self):
        with st.sidebar:
            app = option_menu(
                menu_title='Pondering',
                options=['Home', 'Account', 'Dashboard'],
                icons=['house-fill', 'person-circle', 'clipboard-data'],
                menu_icon='chat-text-fill',
                default_index=0,
                styles={
                    "container": {"padding": "5!important", "background-color": 'black'},
                    "icon": {"color": "white", "font-size": "23px"},
                    "nav-link": {"color": "white", "font-size": "20px", "text-align": "left", "margin": "0px", "--hover-color": "blue"},
                    "nav-link-selected": {"background-color": "#02ab21"},
                }
            )

        # Run the selected app
        for app_dict in self.apps:
            if app == app_dict['title']:
                app_dict['function']()

# Function to validate email format
def is_valid_email(email):
    regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(regex, email) is not None

# Account functionality
def account_app():
    st.title('Welcome to :violet[Pondering] :sunglasses:')

    # Session state initialization
    if 'username' not in st.session_state:
        st.session_state.username = ''
    if 'useremail' not in st.session_state:
        st.session_state.useremail = ''
    if 'role' not in st.session_state:
        st.session_state.role = ''
    if 'signedout' not in st.session_state:
        st.session_state['signedout'] = False

    # Role options
    roles = {
        1: "Operations",
        2: "Supervisor",
        3: "Middle Management",
        4: "Senior Management",
        5: "Executive"
    }

    # Function to sign up user with email, password, username, and role
    def sign_up_with_email_and_password(email, password, username=None, role=None):
        try:
            user = auth.create_user(
                email=email,
                password=password,
                display_name=username
            )
            # Store role in user profile (custom claim)
            auth.set_custom_user_claims(user.uid, {'role': role})
            return user
        except Exception as e:
            st.warning(f'Signup failed: {str(e)}')

    # Function to sign in user with email and password
    def sign_in_with_email_and_password(email, password):
        try:
            user = auth.get_user_by_email(email)
            if user.email == email:  # Check if email matches
                st.session_state.username = user.display_name
                st.session_state.useremail = user.email
                st.session_state.role = user.custom_claims.get('role', 'Unknown')  # Get the user's role
                return user
        except auth.UserNotFoundError:
            st.warning('The email address is not registered.')
        except Exception as e:
            st.warning(f'Signin failed: {str(e)}')

    # User interface for signup/login
    if not st.session_state["signedout"]:
        choice = st.selectbox('Login/Signup', ['Login', 'Sign up'])

        if choice == 'Sign up':
            username = st.text_input("Enter your unique username")
            email = st.text_input('Email Address')
            password = st.text_input('Password', type='password')
            role = st.selectbox("Select your role:", list(roles.values()))  # Role selection for signup

            if st.button('Create my account'):
                if is_valid_email(email):
                    user = sign_up_with_email_and_password(
                        email=email,
                        password=password,
                        username=username,
                        role=list(roles.keys())[list(roles.values()).index(role)]
                    )
                    if user:
                        st.success('Account created successfully! You can now log in.')
                        st.balloons()
                else:
                    st.warning('Please enter a valid email address.')

        else:  # Login
            email = st.text_input('Email Address')
            password = st.text_input('Password', type='password')

            if st.button('Login'):
                if is_valid_email(email):
                    user = sign_in_with_email_and_password(email=email, password=password)
                    if user:
                        st.session_state.signedout = True  # Set user as signed in
                        # Show success message
                        st.success(f'Welcome back, {st.session_state.username}!')
                        st.write(f'Your role is: {st.session_state.role}')
                else:
                    st.warning('Please enter a valid email address.')

# Create the app and add the account functionality
app = MultiApp()
app.add_app("Home", lambda: st.write("Welcome to the home page!"))
app.add_app("Account", account_app)

app.run()
