from flask import Flask, render_template, url_for
import threading
import speech_recognition as sr

app = Flask(__name__)

# Initialize the recognizer
r = sr.Recognizer()
is_recording = False

def record_text():
    global is_recording
    is_recording = True

    while is_recording:
        try:
            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source, duration=1)
                audio = r.listen(source)
                MyText = r.recognize_google(audio)

                print(MyText)  # Print recognized text
                output_text(MyText)  # Save to output.txt

        except sr.RequestError as e:
            print("Could not request results; {0}".format(e))
        
        except sr.UnknownValueError:
            print("Unknown error occurred")

def output_text(text):
    with open("output.txt", "a") as f:
        f.write(text + "\n")

@app.route('/')
def index():
    return render_template('meeting.html')

@app.route('/launch')
def launch():
    # Start the speech recognition in a new thread
    threading.Thread(target=record_text).start()
    return "Zegocloud launched and speech recognition started!"

@app.route('/stop')
def stop():
    global is_recording
    is_recording = False
    return "Speech recognition stopped!"

if __name__ == '__main__':
    app.run(debug=True)
